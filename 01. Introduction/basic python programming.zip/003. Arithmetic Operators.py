# Problem: https://www.hackerrank.com/challenges/python-arithmetic-operators/submissions/code/70402456

a, b = int(input()), int(input())
print((a + b), (a - b), (a * b), sep='\n')
