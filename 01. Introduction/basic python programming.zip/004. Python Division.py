# Problem: https://www.hackerrank.com/challenges/python-division/problem

a, b = int(input()), int(input())
print(a // b, a / b, sep='\n')
