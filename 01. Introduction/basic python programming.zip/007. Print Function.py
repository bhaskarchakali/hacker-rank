# Problem: https://www.hackerrank.com/challenges/python-print/problem

for i in range(1, int(input()) + 1):
    print(i, end='')
