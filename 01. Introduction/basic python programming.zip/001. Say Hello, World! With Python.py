                      #basic python programming
# Problem: https://www.hackerrank.com/challenges/py-hello-world/problem

print('Hello, World!')
