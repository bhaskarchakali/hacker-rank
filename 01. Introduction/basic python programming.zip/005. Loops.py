# Problem: https://www.hackerrank.com/challenges/python-loops/problem

for i in range(int(input())):
    print(i ** 2)
