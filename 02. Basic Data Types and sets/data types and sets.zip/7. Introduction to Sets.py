# Problem: https://www.hackerrank.com/challenges/py-introduction-to-sets/problem



def average(array):
    return sum(set(array)) / len(set(array))
