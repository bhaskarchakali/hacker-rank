# Problem: https://www.hackerrank.com/challenges/python-tuples/problem



n = int(input())
print(hash(tuple(map(int, input().split()))))
