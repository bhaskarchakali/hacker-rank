# Problem: https://www.hackerrank.com/challenges/py-set-add/problem



print(len(set(input() for i in range(int(input())))))
