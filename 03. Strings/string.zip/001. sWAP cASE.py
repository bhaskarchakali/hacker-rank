# Problem: https://www.hackerrank.com/challenges/swap-case/problem

def swap_case(s):
    return s.swapcase()
