# Problem: https://www.hackerrank.com/challenges/whats-your-name/problem

def print_full_name(first_name, last_name):
    print("Hello {} {}! You just delved into python.".format(first_name, last_name))
