# Problem: https://www.hackerrank.com/challenges/text-wrap/problem

def wrap(string, max_width):
    return textwrap.fill(string, max_width)
